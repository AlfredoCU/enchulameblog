package SalesPoint;
import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JTextArea;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SalesPoint {
	String iTax, iSubTotal, iTotal;
	double [] itemCost = new double[21];
	
	private JFrame frmSalesPoint;
	private JTextField appleText;
	private JTextField orangeText;
	private JTextField broccoliText;
	private JTextField lettuceText;
	private JTextField grapesText;
	private JTextField wineText;
	private JTextField rumText;
	private JTextField ginText;
	private JTextField cheeseText;
	private JTextField meatBallsText;
	private JTextField baconText;
	private JTextField meatText;
	private JTextField riceText;
	private JTextField pearText;
	private JTextField beansproText;
	private JTextField cucmberText;
	private JTextField carrotsText;
	private JTextField celeryText;
	private JTextField milkText;
	private JTextField tomatoesText;
	private JTextField taxText;
	private JTextField subTotalText;
	private JTextField totalText;
	private JFrame frame;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalesPoint window = new SalesPoint();
					window.frmSalesPoint.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SalesPoint() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSalesPoint = new JFrame();
		frmSalesPoint.addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent arg0) {
				appleText.setEnabled(true);
				orangeText.setEnabled(true);
				broccoliText.setEnabled(true);
				lettuceText.setEnabled(true);
				grapesText.setEnabled(true);
				wineText.setEnabled(true);
				rumText.setEnabled(true);
				ginText.setEnabled(true);
				cheeseText.setEnabled(true);
				meatBallsText.setEnabled(true);
				baconText.setEnabled(true);
				meatText.setEnabled(true);
				riceText.setEnabled(true);
				pearText.setEnabled(true);
				beansproText.setEnabled(true);
				cucmberText.setEnabled(true);
				carrotsText.setEnabled(true);
				celeryText.setEnabled(true);
				milkText.setEnabled(true);
				tomatoesText.setEnabled(true);
			}
		});
		
		/**
		 * Part 1.
		 */
		frmSalesPoint.setTitle("Sales Point");
		frmSalesPoint.setBounds(0, 0, 1370, 700);
		frmSalesPoint.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSalesPoint.getContentPane().setLayout(new GridLayout(1, 3, 3, 3));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		frmSalesPoint.getContentPane().add(panel_1);
		panel_1.setLayout(new GridLayout(1, 4, 1, 1));
		
		JPanel panel_5 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_5.getLayout();
		flowLayout.setVgap(38);
		panel_1.add(panel_5);
		
		JLabel lblApple = new JLabel("Apple");
		lblApple.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_5.add(lblApple);
		
		appleText = new JTextField();
		appleText.setHorizontalAlignment(SwingConstants.CENTER);
		appleText.setText("0");
		appleText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		appleText.setColumns(20);
		panel_5.add(appleText);
		
		JLabel lblOrnge = new JLabel("Orange");
		lblOrnge.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblOrnge.setBounds(10, 11, 60, 35);
		panel_5.add(lblOrnge);
		
		orangeText = new JTextField();
		orangeText.setHorizontalAlignment(SwingConstants.CENTER);
		orangeText.setText("0");
		orangeText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		orangeText.setColumns(20);
		panel_5.add(orangeText);
		
		JLabel lblBroccoli = new JLabel("Broccoli");
		lblBroccoli.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_5.add(lblBroccoli);
		
		broccoliText = new JTextField();
		broccoliText.setHorizontalAlignment(SwingConstants.CENTER);
		broccoliText.setText("0");
		broccoliText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		broccoliText.setColumns(20);
		panel_5.add(broccoliText);
		
		JLabel lblLettuce = new JLabel("Lettuce");
		lblLettuce.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_5.add(lblLettuce);
		
		lettuceText = new JTextField();
		lettuceText.setHorizontalAlignment(SwingConstants.CENTER);
		lettuceText.setText("0");
		lettuceText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lettuceText.setColumns(20);
		panel_5.add(lettuceText);
		
		JLabel lblGrapes = new JLabel("Grapes");
		lblGrapes.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_5.add(lblGrapes);
		
		grapesText = new JTextField();
		grapesText.setHorizontalAlignment(SwingConstants.CENTER);
		grapesText.setText("0");
		grapesText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		grapesText.setColumns(20);
		panel_5.add(grapesText);
		
		JPanel panel_6 = new JPanel();
		FlowLayout flowLayout1 = (FlowLayout) panel_6.getLayout();
		flowLayout1.setVgap(38);
		panel_1.add(panel_6);
		
		JLabel lblWine= new JLabel("Wine");
		lblWine.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_6.add(lblWine);
		
		wineText = new JTextField();
		wineText.setHorizontalAlignment(SwingConstants.CENTER);
		wineText.setText("0");
		wineText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		wineText.setColumns(20);
		panel_6.add(wineText);
		
		JLabel lblRum = new JLabel("Rum");
		lblRum.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_6.add(lblRum);
		
		rumText = new JTextField();
		rumText.setHorizontalAlignment(SwingConstants.CENTER);
		rumText.setText("0");
		rumText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rumText.setColumns(20);
		panel_6.add(rumText);
		
		JLabel lblGin = new JLabel("Gin");
		lblGin.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_6.add(lblGin);
		
		ginText = new JTextField();
		ginText.setHorizontalAlignment(SwingConstants.CENTER);
		ginText.setText("0");
		ginText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		ginText.setColumns(20);
		panel_6.add(ginText);
		
		JLabel lblCheese = new JLabel("Cheese");
		lblCheese.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_6.add(lblCheese);
		
		cheeseText = new JTextField();
		cheeseText.setHorizontalAlignment(SwingConstants.CENTER);
		cheeseText.setText("0");
		cheeseText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		cheeseText.setColumns(20);
		panel_6.add(cheeseText);
		
		JLabel lblMeatBalls = new JLabel("Meatballs");
		lblMeatBalls.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_6.add(lblMeatBalls);
		
		meatBallsText = new JTextField();
		meatBallsText.setHorizontalAlignment(SwingConstants.CENTER);
		meatBallsText.setText("0");
		meatBallsText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		meatBallsText.setColumns(20);
		panel_6.add(meatBallsText);
		
		JPanel panel_7 = new JPanel();
		FlowLayout flowLayout2 = (FlowLayout) panel_7.getLayout();
		flowLayout2.setVgap(38);
		panel_1.add(panel_7);
		
		JLabel lblBacon = new JLabel("Bacon");
		lblBacon.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_7.add(lblBacon);
		
		baconText = new JTextField();
		baconText.setHorizontalAlignment(SwingConstants.CENTER);
		baconText.setText("0");
		baconText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		baconText.setColumns(20);
		panel_7.add(baconText);
		
		JLabel lblMeat = new JLabel("Meat");
		lblMeat.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_7.add(lblMeat);
		
		meatText = new JTextField();
		meatText.setHorizontalAlignment(SwingConstants.CENTER);
		meatText.setText("0");
		meatText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		meatText.setColumns(20);
		panel_7.add(meatText);
		
		JLabel lblRice = new JLabel("Rice");
		lblRice.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_7.add(lblRice);
		
		riceText = new JTextField();
		riceText.setHorizontalAlignment(SwingConstants.CENTER);
		riceText.setText("0");
		riceText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		riceText.setColumns(20);
		panel_7.add(riceText);
		
		JLabel lblPear = new JLabel("Pear");
		lblPear.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_7.add(lblPear);
		
		pearText = new JTextField();
		pearText.setHorizontalAlignment(SwingConstants.CENTER);
		pearText.setText("0");
		pearText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		pearText.setColumns(20);
		panel_7.add(pearText);

		JLabel lblBeans = new JLabel("Beans");
		lblBeans.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_7.add(lblBeans);
		
		beansproText = new JTextField();
		beansproText.setHorizontalAlignment(SwingConstants.CENTER);
		beansproText.setText("0");
		beansproText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		beansproText.setColumns(20);
		panel_7.add(beansproText);
		
		JPanel panel_8 = new JPanel();
		FlowLayout flowLayout3 = (FlowLayout) panel_8.getLayout();
		flowLayout3.setVgap(38);
		panel_1.add(panel_8);
		
		JLabel lblCucmber = new JLabel("Cucmber");
		lblCucmber.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_8.add(lblCucmber);
		
		cucmberText = new JTextField();
		cucmberText.setHorizontalAlignment(SwingConstants.CENTER);
		cucmberText.setText("0");
		cucmberText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		cucmberText.setColumns(20);
		panel_8.add(cucmberText);
		
		JLabel lblCarrots = new JLabel("Carrots");
		lblCarrots.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_8.add(lblCarrots);
		
		carrotsText = new JTextField();
		carrotsText.setHorizontalAlignment(SwingConstants.CENTER);
		carrotsText.setText("0");
		carrotsText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		carrotsText.setColumns(20);
		panel_8.add(carrotsText);
		
		JLabel lblCelery = new JLabel("Celery");
		lblCelery.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_8.add(lblCelery);
		
		celeryText = new JTextField();
		celeryText.setHorizontalAlignment(SwingConstants.CENTER);
		celeryText.setText("0");
		celeryText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		celeryText.setColumns(20);
		panel_8.add(celeryText);
		
		JLabel lblMilk = new JLabel("Milk");
		lblMilk.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_8.add(lblMilk);
		
		milkText = new JTextField();
		milkText.setHorizontalAlignment(SwingConstants.CENTER);
		milkText.setText("0");
		milkText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		milkText.setColumns(20);
		panel_8.add(milkText);
		
		JLabel lblTomatoes = new JLabel("Tomatoes");
		lblTomatoes.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_8.add(lblTomatoes);
		
		tomatoesText = new JTextField();
		tomatoesText.setHorizontalAlignment(SwingConstants.CENTER);
		tomatoesText.setText("0");
		tomatoesText.setFont(new Font("Tahoma", Font.PLAIN, 18));
		tomatoesText.setColumns(20);
		panel_8.add(tomatoesText);		
		
		/**
		 * Part 2.
		 */
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		frmSalesPoint.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Tax");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setBounds(10, 11, 60, 35);
		panel_2.add(lblNewLabel);
		
		taxText = new JTextField();
		taxText.setEditable(false);
		taxText.setText("0");
		taxText.setHorizontalAlignment(SwingConstants.CENTER);
		taxText.setFont(new Font("Tahoma", Font.BOLD, 24));
		taxText.setBounds(161, 11, 203, 35);
		panel_2.add(taxText);
		taxText.setColumns(10);
		
		JLabel lblTotal = new JLabel("SubTotal");
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblTotal.setBounds(10, 70, 119, 29);
		panel_2.add(lblTotal);
		
		subTotalText = new JTextField();
		subTotalText.setEditable(false);
		subTotalText.setText("0");
		subTotalText.setHorizontalAlignment(SwingConstants.CENTER);
		subTotalText.setFont(new Font("Tahoma", Font.BOLD, 24));
		subTotalText.setColumns(10);
		subTotalText.setBounds(161, 67, 203, 35);
		panel_2.add(subTotalText);
		
		JLabel lblTotal_1 = new JLabel("Total");
		lblTotal_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblTotal_1.setBounds(10, 134, 119, 29);
		panel_2.add(lblTotal_1);
		
		totalText = new JTextField();
		totalText.setEditable(false);
		totalText.setText("0");
		totalText.setHorizontalAlignment(SwingConstants.CENTER);
		totalText.setFont(new Font("Tahoma", Font.BOLD, 24));
		totalText.setColumns(10);
		totalText.setBounds(161, 131, 203, 35);
		panel_2.add(totalText);
		
		JTextArea receiptText = new JTextArea();
		receiptText.setEditable(false);
		receiptText.setBounds(10, 215, 410, 302);
		panel_2.add(receiptText);
		
		JButton totalButton = new JButton("Total");
		totalButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {		
				itemCost[0] = Double.parseDouble(appleText.getText()) * 1.50;
				itemCost[1] = Double.parseDouble(orangeText.getText()) * 1.87;
				itemCost[2] = Double.parseDouble(broccoliText.getText()) * 1.10;
				itemCost[3] = Double.parseDouble(grapesText.getText()) * 2.00;
				itemCost[4] = Double.parseDouble(wineText.getText()) * 0.99;
				itemCost[5] = Double.parseDouble(rumText.getText()) * 1.5;
				itemCost[6] = Double.parseDouble(ginText.getText()) * 1.24;
				itemCost[7] = Double.parseDouble(cheeseText.getText()) * 6.5;
				itemCost[8] = Double.parseDouble(meatBallsText.getText()) * 10.2;
				itemCost[9] = Double.parseDouble(baconText.getText()) * 11.5;
				itemCost[11] = Double.parseDouble(meatText.getText()) * 2.5;
				itemCost[12] = Double.parseDouble(riceText.getText()) * 7.5;
				itemCost[13] = Double.parseDouble(pearText.getText()) * 1.50;
				itemCost[14] = Double.parseDouble(beansproText.getText()) * 0.95;
				itemCost[15] = Double.parseDouble(cucmberText.getText()) * 8.5;
				
				itemCost[16] = itemCost[0] + itemCost[1] + itemCost[2] + itemCost[3] + itemCost[4] + itemCost[5] + itemCost[6];
				itemCost[17] = itemCost[7] + itemCost[8] + itemCost[9] + itemCost[10] + itemCost[11] + itemCost[12] + itemCost[13];
				itemCost[19] = itemCost[14] + itemCost[15] + itemCost[16] + itemCost[17];
				itemCost[20] = itemCost[17] + itemCost[18] + itemCost[19];
				
				iTax = String.format("$ %.2f", itemCost[20] / 100);
				iSubTotal = String.format("$ %.2f", itemCost[20]);
				iTotal = String.format("$ %.2f", itemCost[20] + (itemCost[20] / 100));
				
				taxText.setText(iTax);
				subTotalText.setText(iSubTotal);
				totalText.setText(iTotal);
				
				receiptText.setEnabled(true);
				int refs = 1325 + (int) (Math.random() * 4238 );
				
				Calendar timer = Calendar.getInstance();
				timer.getTime();
				SimpleDateFormat tTime = new SimpleDateFormat("HH:mm:ss");
				tTime.format(timer.getTime());
				SimpleDateFormat Tdate = new SimpleDateFormat("dd-MMM-yyyy");
				Tdate.format(timer.getTime());
				
				receiptText.append("\tSales Point\n" + 
				"Reference\t\t\t" + refs + 
				"\n**************************************************************************\t" + 
					"\nTax: \t\t\t\t" + iTax +
					"\nSubTotal \t\t\t\t" + iSubTotal +
					"\nTotal:\t\t\t\t" + iTotal + 
					"\n**************************************************************************\t" + 
					"\nDate: " + Tdate.format(timer.getTime()) + 
							"\t\tTime: " + tTime.format(timer.getTime()) + 
					"\n\n\n Thank your for Shopping"
				);
			}
		});
		
		totalButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		totalButton.setBounds(10, 580, 89, 23);
		panel_2.add(totalButton);
		
		JButton resetButton = new JButton("Reset");
		resetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				appleText.setText("0");
				orangeText.setText("0");
				broccoliText.setText("0");
				lettuceText.setText("0");
				grapesText.setText("0");
				wineText.setText("0");
				rumText.setText("0");
				ginText.setText("0");
				cheeseText.setText("0");
				meatBallsText.setText("0");
				baconText.setText("0");
				meatText.setText("0");
				riceText.setText("0");
				pearText.setText("0");
				beansproText.setText("0");
				cucmberText.setText("0");
				carrotsText.setText("0");
				celeryText.setText("0");
				milkText.setText("0");
				tomatoesText.setText("0");
				
				totalText.setText("0");
				subTotalText.setText("0");
				taxText.setText("0");
				receiptText.setText("");
			}
		});
		
		resetButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		resetButton.setBounds(181, 580, 89, 23);
		panel_2.add(resetButton);
		
		JButton exitButton = new JButton("Exit");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame, "Confirme if you want to exit", "Sales Point",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		
		exitButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		exitButton.setBounds(331, 580, 89, 23);
		panel_2.add(exitButton);
	}
}