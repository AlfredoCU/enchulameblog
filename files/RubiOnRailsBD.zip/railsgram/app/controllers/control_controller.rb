class ControlController < ApplicationController
	def saludo
		@myName = 'Moisés'
	end
end
