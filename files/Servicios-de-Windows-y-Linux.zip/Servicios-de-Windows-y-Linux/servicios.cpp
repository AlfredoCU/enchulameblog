#include <iostream>
#include <cstdlib>
#ifdef _WIN32
#define TO_SHOW 0
#else
#define TO_SHOW 1
#endif
using namespace std;

void showWindowsServices() {
    cout<<"Listando los servicios corriendo de Windows"<<endl;
    system("net start");
    system("pause");
    cout<<"Listando todos los servicios de Windows"<<endl;
    system("wmic service get name");
}

void showLinuxServices() {
    cout<<"Listando los servicios de Linux"<<endl;
    system("ps aux");
    system("pause");
}


void servicesToShow(int system) {
    if(system)
        showLinuxServices();
    else
        showWindowsServices();
}

bool continueExecution = true;

int main() {
    char selection;
    do {
        servicesToShow(TO_SHOW);
        system("pause");
        cout<<"Presione e para salir, presione otra tecla para continuar: ";
        cin>>selection;
        if (selection == 'e' || selection == 'E')
            continueExecution = false;
    } while (continueExecution);
    return 0;
}
